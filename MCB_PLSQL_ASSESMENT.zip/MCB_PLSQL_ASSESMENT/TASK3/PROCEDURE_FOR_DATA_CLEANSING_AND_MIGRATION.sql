--------------------------------------------------------------------------------------------------------------------------------------------------------------
/*				PROCEDURE TO CLEANSE ORDER DATA			*/
--------------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE PROCEDURE cleanse_order_data AS
    -- Local variables for storing sql statement and error message
    var_sql       VARCHAR2(4000);
    var_error_msg VARCHAR2(4000);

    -- Cursors for ORDER_REF cleansing
    CURSOR base_ref_cursor IS
        SELECT DISTINCT SUBSTR(ORDER_REF, 1, INSTR(ORDER_REF || '-', '-', 1, 1) - 1) AS base_ref
        FROM XXBCM_ORDER_MGT
        WHERE INSTR(ORDER_REF, '-') = 0;

    CURSOR order_ref_cursor (p_base_ref VARCHAR2) IS
        SELECT ORDER_REF, 
               ROWID AS rid, 
               ROW_NUMBER() OVER (ORDER BY ORDER_REF) AS row_num
        FROM XXBCM_ORDER_MGT
        WHERE ORDER_REF LIKE p_base_ref || '-%'
        ORDER BY ORDER_REF;

    -- Variables for ORDER_REF cleansing
    var_base_ref VARCHAR2(100);
    var_new_order_ref VARCHAR2(100);

BEGIN
    -- Step 1: Cleanse Amount columns by removing commas
    var_sql := 'UPDATE XXBCM_ORDER_MGT 
              SET ORDER_TOTAL_AMOUNT = REPLACE(ORDER_TOTAL_AMOUNT, '','', ''''),
                  ORDER_LINE_AMOUNT = REPLACE(ORDER_LINE_AMOUNT, '','', ''''),
                  INVOICE_AMOUNT = REPLACE(INVOICE_AMOUNT, '','', '''')';
    EXECUTE IMMEDIATE var_sql;

    -- Step 2: Remove . from the SUPP_CONTACT_NUMBER column
    var_sql := 'UPDATE XXBCM_ORDER_MGT 
              SET SUPP_CONTACT_NUMBER = REPLACE(SUPP_CONTACT_NUMBER, ''.'', '''')';
    EXECUTE IMMEDIATE var_sql;

    -- Step 3: Remove spaces from the SUPP_CONTACT_NUMBER column
    var_sql := 'UPDATE XXBCM_ORDER_MGT 
              SET SUPP_CONTACT_NUMBER = REPLACE(SUPP_CONTACT_NUMBER, '' '', '''')';
    EXECUTE IMMEDIATE var_sql;

    -- Step 4: Replace I,i,O,o,S,s with 1,1,0,0,5,5 in relevant columns
    var_sql := 'UPDATE XXBCM_ORDER_MGT 
              SET ORDER_TOTAL_AMOUNT = TRANSLATE(ORDER_TOTAL_AMOUNT, ''IOSiosO'', ''1051050''),
                  ORDER_LINE_AMOUNT = TRANSLATE(ORDER_LINE_AMOUNT, ''IOSiosO'', ''1051050''),
                  INVOICE_AMOUNT = TRANSLATE(INVOICE_AMOUNT, ''IOSiosO'', ''1051050''),
                  SUPP_CONTACT_NUMBER = TRANSLATE(SUPP_CONTACT_NUMBER, ''IOSiosO'', ''1051050'')';
    EXECUTE IMMEDIATE var_sql;

    -- Step 5: Convert ORDER_DATE and INVOICE_DATE to DD-MON-YYYY format
    var_sql := 'UPDATE XXBCM_ORDER_MGT 
              SET ORDER_DATE = TO_CHAR(TO_DATE(ORDER_DATE, 
                            CASE 
                              WHEN ORDER_DATE LIKE ''%/%/%'' THEN ''DD/MM/YYYY''
                              WHEN ORDER_DATE LIKE ''%-MON-YY'' THEN ''DD-MON-YY''
                              WHEN ORDER_DATE LIKE ''%-MON-YYYY'' THEN ''DD-MON-YYYY''
                              ELSE ''DD-MM-YYYY''
                            END), ''DD-MON-YYYY''),
                  INVOICE_DATE = TO_CHAR(TO_DATE(INVOICE_DATE, 
                            CASE 
                              WHEN INVOICE_DATE LIKE ''%/%/%'' THEN ''DD/MM/YYYY''
                              WHEN INVOICE_DATE LIKE ''%-MON-YY'' THEN ''DD-MON-YY''
                              WHEN INVOICE_DATE LIKE ''%-MON-YYYY'' THEN ''DD-MON-YYYY''
                              ELSE ''DD-MM-YYYY''
                            END), ''DD-MON-YYYY'')';
    EXECUTE IMMEDIATE var_sql;

    -- Step 6: Cleanse the ORDER_REF column and ensure unique and sequential suffixes separated by -
    FOR base_ref_recrd IN base_ref_cursor LOOP
        var_base_ref := base_ref_recrd.base_ref;

        -- Iterate through all ORDER_REF values with the same base reference and a suffix
        FOR order_ref_rec IN order_ref_cursor(var_base_ref) LOOP
            -- Construct the new ORDER_REF with counter as the unique suffix
            var_new_order_ref := var_base_ref || '-' || order_ref_rec.row_num;

            -- Update the ORDER_REF
            UPDATE XXBCM_ORDER_MGT
            SET ORDER_REF = var_new_order_ref
            WHERE ROWID = order_ref_rec.rid;
        END LOOP;
    END LOOP;

    -- Step 7: Commit the transaction
    COMMIT;
	
	DBMS_OUTPUT.PUT_LINE('Order Data cleansed successfully.');
	
EXCEPTION
    WHEN OTHERS THEN
        -- Rollback the transaction in case of any errors
        ROLLBACK;
        
        -- Capture the error message and print it
        var_error_msg := SQLERRM;
        RAISE_APPLICATION_ERROR(-20001, 'Error in cleansing data: ' || var_error_msg);
END cleanse_order_data;
/


--------------------------------------------------------------------------------------------------------------------------------------------------------------
/*				PROCEDURE TO CLEANSE INVOICE_REFERENCE COLUMN			*/
--------------------------------------------------------------------------------------------------------------------------------------------------------------

create or replace PROCEDURE CLEANSE_INVOICE_REFS AS
  CURSOR prefix_cursor IS
    SELECT DISTINCT SUBSTR(invoice_reference, 1, INSTR(invoice_reference, '.') - 1) AS prefix
    FROM xxbcm_order_mgt
    WHERE invoice_reference IS NOT NULL AND INSTR(invoice_reference, '.') > 0
    order by prefix;

  CURSOR invoice_cursor(var_prefix VARCHAR2) IS
    SELECT invoice_reference,
    ROWID AS rid, 
    ROW_NUMBER() OVER (ORDER BY ORDER_REF) AS row_num
    FROM xxbcm_order_mgt
    WHERE invoice_reference LIKE var_prefix || '%'
    AND invoice_reference IS NOT NULL
    order by ORDER_REF;

  var_prefix     VARCHAR2(100);
  var_new_ref    VARCHAR2(100);
  counter      NUMBER := 1;

BEGIN
  -- Loop for each distinct prefix
  FOR prefix_rec IN prefix_cursor LOOP
    var_prefix := prefix_rec.prefix;
    
    -- Loop for each invoice_reference having same prefix
    FOR inv_rec IN invoice_cursor(var_prefix) LOOP
      -- Cleanse the invoice_reference by removing the suffix and . , then appending the counter separated by -
      var_new_ref := var_prefix || '-' || TO_CHAR(counter);

      -- Update the xxbcm_order_mgt table with the new invoice_reference
        UPDATE xxbcm_order_mgt
        SET invoice_reference = var_new_ref
        WHERE invoice_reference = inv_rec.invoice_reference
        AND ROWID = inv_rec.rid;


      -- Increse the counter
      counter := counter + 1;
    END LOOP;

    -- Reset the counter for the next prefix
    counter := 1;
  END LOOP;

  -- Commit the changes
  COMMIT;
  DBMS_OUTPUT.PUT_LINE('Invoice Reference Data cleansed successfully.');
  
EXCEPTION
  WHEN OTHERS THEN
    -- Handle exceptions
	DBMS_OUTPUT.PUT_LINE('Error cleansing invoice reference data: ' || SQLERRM);
    ROLLBACK;
    RAISE;
END CLEANSE_INVOICE_REFS;
/

--------------------------------------------------------------------------------------------------------------------------------------------------------------
/*				PROCEDURE TO MIGRATE SUPPLIER DATA		*/
--------------------------------------------------------------------------------------------------------------------------------------------------------------

create or replace PROCEDURE MIGRATE_SUPPLIER_DATA IS
    CURSOR order_cursor IS
        SELECT DISTINCT SUPPLIER_NAME
        FROM XXBCM_ORDER_MGT;
    
    v_supplier_id VARCHAR2(10);
    v_supplier_name VARCHAR2(100);
    
    -- Function to replace multiple spaces with a single space
    FUNCTION replace_multiple_spaces(text VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
        RETURN REGEXP_REPLACE(text, '\s+', ' ');
    END;
    
BEGIN
    FOR order_rec IN order_cursor LOOP
        BEGIN
            -- Cleanse supplier name
            v_supplier_name := replace_multiple_spaces(order_rec.SUPPLIER_NAME);
            
            -- Generate SUPPLIER_ID
            SELECT 'SUP' || TO_CHAR(XXBCM_SEQ_SUPPLIER_ID.NEXTVAL, 'FM000000') INTO v_supplier_id FROM DUAL;
            
            -- Insert into XXBCM_SUPPLIER_NAME
            INSERT INTO XXBCM_SUPPLIER_NAME (SUPPLIER_ID, SUPPLIER_NAME)
            VALUES (v_supplier_id, v_supplier_name);
        
        EXCEPTION
            WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE('Error inserting supplier: ' || SQLERRM);
        END;
    END LOOP;
    
    COMMIT;
	DBMS_OUTPUT.PUT_LINE('Supplier Data migrated successfully.');

EXCEPTION
  WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('Error inserting supplier data: ' || SQLERRM);
    ROLLBACK;
    RAISE;
	
END MIGRATE_SUPPLIER_DATA;
/


--------------------------------------------------------------------------------------------------------------------------------------------------------------
/*				PROCEDURE TO MIGRATE SUPPLIER CONTACT DATA		*/
--------------------------------------------------------------------------------------------------------------------------------------------------------------

create or replace PROCEDURE MIGRATE_SUPPLIER_CONTACT_DATA IS
    CURSOR contact_cursor IS
        SELECT DISTINCT SUPPLIER_NAME, SUPP_CONTACT_NAME, SUPP_CONTACT_NUMBER, SUPP_EMAIL
        FROM XXBCM_ORDER_MGT;
    
    v_supplier_contact_id VARCHAR2(10);
    v_supplier_id VARCHAR2(10);
    v_contact_number1 VARCHAR2(50);
    v_contact_number2 VARCHAR2(50);
    
BEGIN
    FOR contact_rec IN contact_cursor LOOP
        BEGIN
            -- Generate SUPPLIER_CONTACT_ID
            SELECT 'CON' || TO_CHAR(XXBCM_SEQ_SUPPLIER_CONTACT_ID.NEXTVAL, 'FM000000') INTO v_supplier_contact_id FROM DUAL;
            
            -- Get SUPPLIER_ID from XXBCM_SUPPLIER_NAME
            SELECT SUPPLIER_ID INTO v_supplier_id
            FROM XXBCM_SUPPLIER_NAME
            WHERE SUPPLIER_NAME = contact_rec.SUPPLIER_NAME;
            
            -- Split contact number into two parts if there is a comma
            v_contact_number1 := SUBSTR(contact_rec.SUPP_CONTACT_NUMBER, 1, INSTR(contact_rec.SUPP_CONTACT_NUMBER, ',') - 1);
            v_contact_number2 := SUBSTR(contact_rec.SUPP_CONTACT_NUMBER, INSTR(contact_rec.SUPP_CONTACT_NUMBER, ',') + 1);
            
            -- Ensure v_contact_number1 is not NULL
            IF v_contact_number1 IS NULL OR v_contact_number1 = '' THEN
                v_contact_number1 := contact_rec.SUPP_CONTACT_NUMBER;
                v_contact_number2 := NULL;
            END IF;
            
            -- If v_contact_number2 is still NULL or empty, set it to NULL explicitly
            IF v_contact_number2 IS NULL OR v_contact_number2 = '' THEN
                v_contact_number2 := NULL;
            END IF;
            
            -- Insert into XXBCM_SUPPLIER_CONTACT
            INSERT INTO XXBCM_SUPPLIER_CONTACT (SUPPLIER_CONTACT_ID, SUPPLIER_ID, SUPP_CONTACT_NAME, SUPP_CONTACT_NUMBER1, SUPP_CONTACT_NUMBER2, SUPP_EMAIL)
            VALUES (v_supplier_contact_id, v_supplier_id, contact_rec.SUPP_CONTACT_NAME, v_contact_number1, v_contact_number2, contact_rec.SUPP_EMAIL);
        
        EXCEPTION
            WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE('Error inserting supplier contact: ' || SQLERRM);
        END;
    END LOOP;
    
    COMMIT;
	DBMS_OUTPUT.PUT_LINE('Supplier Contact Data migrated successfully.');

EXCEPTION
  WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('Error inserting supplier contact: ' || SQLERRM);
    ROLLBACK;
    RAISE;
	
END MIGRATE_SUPPLIER_CONTACT_DATA;
/


--------------------------------------------------------------------------------------------------------------------------------------------------------------
/*				PROCEDURE TO MIGRATE SUPPLIER ADDRESS DATA		*/
--------------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE PROCEDURE MIGRATE_SUPPLIER_ADDRESS_DATA IS
    CURSOR address_cursor IS
        SELECT DISTINCT SUPPLIER_NAME, SUPP_ADDRESS
        FROM XXBCM_ORDER_MGT;
    
    v_supplier_address_id VARCHAR2(10);
    v_supplier_id VARCHAR2(10);
    v_line1 VARCHAR2(200);
    v_line2 VARCHAR2(1000);
    v_line3 VARCHAR2(1000);
    v_city VARCHAR2(500);
    v_country VARCHAR2(500);
    
    -- Function to split address into components
    FUNCTION split_address(full_address VARCHAR2) RETURN SYS.ODCIVARCHAR2LIST IS
        address_parts SYS.ODCIVARCHAR2LIST := SYS.ODCIVARCHAR2LIST();
        v_temp VARCHAR2(4000);
        v_pos PLS_INTEGER := 1;
        v_start PLS_INTEGER := 1;
    BEGIN
        LOOP
            v_pos := INSTR(full_address, ',', v_start);
            EXIT WHEN v_pos = 0;
            v_temp := SUBSTR(full_address, v_start, v_pos - v_start);
            address_parts.EXTEND;
            address_parts(address_parts.COUNT) := TRIM(v_temp);
            v_start := v_pos + 1;
        END LOOP;
        
        v_temp := SUBSTR(full_address, v_start);
        address_parts.EXTEND;
        address_parts(address_parts.COUNT) := TRIM(v_temp);
        
        RETURN address_parts;
    END;
    
BEGIN
    FOR address_rec IN address_cursor LOOP
        BEGIN
            -- Generate SUPPLIER_ADDRESS_ID
            SELECT 'ADD' || TO_CHAR(XXBCM_SEQ_SUPPLIER_ADDRESS_ID.NEXTVAL, 'FM000000') INTO v_supplier_address_id FROM DUAL;
            
            -- Get SUPPLIER_ID from XXBCM_SUPPLIER_NAME
            SELECT SUPPLIER_ID INTO v_supplier_id
            FROM XXBCM_SUPPLIER_NAME
            WHERE SUPPLIER_NAME = address_rec.SUPPLIER_NAME;
            
            -- Split address
            DECLARE
                address_parts SYS.ODCIVARCHAR2LIST := split_address(address_rec.SUPP_ADDRESS);
            BEGIN
                v_line1 := CASE WHEN address_parts.COUNT >= 1 THEN address_parts(1) ELSE NULL END;
                v_line2 := CASE WHEN address_parts.COUNT >= 2 THEN address_parts(2) ELSE NULL END;
                v_line3 := CASE WHEN address_parts.COUNT >= 3 THEN address_parts(3) ELSE NULL END;
                v_city := CASE WHEN address_parts.COUNT >= 4 THEN address_parts(4) ELSE NULL END;
                v_country := CASE WHEN address_parts.COUNT >= 5 THEN address_parts(5) ELSE NULL END;
            END;
            
            -- Insert into XXBCM_SUPPLIER_ADDRESS
            INSERT INTO XXBCM_SUPPLIER_ADDRESS (SUPPLIER_ADDRESS_ID, SUPPLIER_ID, SUPP_ADDRESS_Line1, SUPP_ADDRESS_Line2, SUPP_ADDRESS_Line3, City, Country)
            VALUES (v_supplier_address_id, v_supplier_id, v_line1, v_line2, v_line3, v_city, v_country);
        
        EXCEPTION
            WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE('Error inserting supplier address: ' || SQLERRM);
        END;
    END LOOP;
    
    COMMIT;
	DBMS_OUTPUT.PUT_LINE('Supplier Address Data migrated successfully.');
	
EXCEPTION
  WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('Error inserting supplier address: ' || SQLERRM);
    ROLLBACK;
    RAISE;	
	
END MIGRATE_SUPPLIER_ADDRESS_DATA;
/


--------------------------------------------------------------------------------------------------------------------------------------------------------------
/*				PROCEDURE TO MIGRATE ORDER HEADER DATA		*/
--------------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE PROCEDURE MIGRATE_ORDER_HEADER AS 
BEGIN
  FOR rec IN (SELECT * FROM XXbcm_ORDER_mgt WHERE ORDER_REF NOT LIKE '%-%') LOOP
    INSERT INTO XXBCM_ORDER_HEADER (
      ORDER_REF,
      ORDER_DATE,
      SUPPLIER_ID,
      ORDER_TOTAL_AMOUNT,
      ORDER_DESCRIPTION,
      ORDER_STATUS
    ) VALUES (
      rec.ORDER_REF,
      TO_DATE(rec.ORDER_DATE, 'DD-Mon-YY'),
      (SELECT SUPPLIER_ID FROM XXBCM_SUPPLIER_NAME WHERE SUPPLIER_NAME = rec.SUPPLIER_NAME),
      rec.ORDER_TOTAL_AMOUNT,
      rec.ORDER_DESCRIPTION,
      rec.ORDER_STATUS
    );
  END LOOP;
  
  COMMIT;
  DBMS_OUTPUT.PUT_LINE('Order Header Data migrated successfully.');
  
EXCEPTION
  WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('Error inserting order header: ' || SQLERRM);
    ROLLBACK;
    RAISE;
END MIGRATE_ORDER_HEADER;


--------------------------------------------------------------------------------------------------------------------------------------------------------------
/*				PROCEDURE TO MIGRATE ORDER LINE DATA		*/
--------------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE PROCEDURE MIGRATE_ORDER_LINES AS
  CURSOR order_line_cursor IS
    SELECT 
      ORDER_REF, 
      To_NUMBER(SUBSTR(ORDER_REF, INSTR(ORDER_REF, '-') + 1),'99999999') AS LINE_NUM,
      ORDER_DESCRIPTION, 
      ORDER_LINE_AMOUNT, 
      ORDER_STATUS, 
      ORDER_DATE
    FROM 
      XXBCM_ORDER_MGT
    WHERE 
      ORDER_LINE_AMOUNT IS NOT NULL
	order by SUBSTR(ORDER_REF, 1, INSTR(ORDER_REF || '-', '-', 1, 1) - 1),TO_NUMBER(SUBSTR(ORDER_REF, INSTR(ORDER_REF, '-') + 1),'99999999');

  v_order_line_id   VARCHAR2(10);
  v_order_id        VARCHAR2(10);
  
BEGIN
  FOR order_rec IN order_line_cursor LOOP
    -- Extract order ID from XXBCM_ORDER_HEADER based on the prefix of ORDER_REF
    SELECT ORDER_ID INTO v_order_id
    FROM XXBCM_ORDER_HEADER
    WHERE ORDER_REF = SUBSTR(order_rec.ORDER_REF, 1, INSTR(order_rec.ORDER_REF, '-') - 1);

    -- Generate ORDER_LINE_ID using the sequence
    v_order_line_id := 'OLN' || TO_CHAR(XXBCM_SEQ_ORDER_LINE_ID.NEXTVAL, 'FM000000');
    
    BEGIN
      -- Insert data into XXBCM_ORDER_LINE table
    INSERT INTO XXBCM_ORDER_LINE (
        ORDER_LINE_ID, 
        ORDER_ID, 
        ORDER_LINE_NUM, 
        ORDER_LINE_DESCRIPTION, 
        ORDER_LINE_AMOUNT, 
        ORDER_LINE_STATUS, 
        ORDER_DATE
      ) VALUES (
        v_order_line_id, 
        v_order_id, 
        order_rec.LINE_NUM, 
        order_rec.ORDER_DESCRIPTION, 
        order_rec.ORDER_LINE_AMOUNT, 
        order_rec.ORDER_STATUS, 
        TO_DATE(order_rec.ORDER_DATE, 'DD-Mon-YY')
      );
	  
    EXCEPTION
      WHEN OTHERS THEN
        -- Handle any errors that occur during the insert
        DBMS_OUTPUT.PUT_LINE('Error inserting order line for ORDER_REF ' || order_rec.ORDER_REF || ': ' || SQLERRM);
        -- Optionally, rollback if needed
        ROLLBACK;
    END;
  END LOOP;
  
  -- Commit the transaction if everything is successful
  COMMIT;
  
  DBMS_OUTPUT.PUT_LINE('Order Lines Data migrated successfully.');
  
EXCEPTION
  WHEN OTHERS THEN
    -- Handle any other exceptions that might occur
    DBMS_OUTPUT.PUT_LINE('Error inserting order line: ' || SQLERRM);
    ROLLBACK;
END MIGRATE_ORDER_LINES;
/


--------------------------------------------------------------------------------------------------------------------------------------------------------------
/*				PROCEDURE TO MIGRATE INVOICE HEADER DATA		*/
--------------------------------------------------------------------------------------------------------------------------------------------------------------

create or replace PROCEDURE MIGRATE_INVOICE_HEADER_DATA AS
    -- Cursor to fetch distinct invoice references with oldest invoice dates
    CURSOR invoice_cur IS
        SELECT DISTINCT
            CASE
                WHEN INSTR(INVOICE_REFERENCE, '-', 1, 1) > 0 THEN 
                    SUBSTR(INVOICE_REFERENCE, 1, INSTR(INVOICE_REFERENCE, '-', 1, 1) - 1)
                ELSE
                    INVOICE_REFERENCE
            END AS invoice_ref_prefix,
            MIN(TO_DATE(INVOICE_DATE, 'DD-MON-YY')) AS oldest_date
        FROM
            XXBCM_ORDER_MGT
        WHERE INVOICE_REFERENCE IS NOT NULL
        GROUP BY
            CASE
                WHEN INSTR(INVOICE_REFERENCE, '-', 1, 1) > 0 THEN 
                    SUBSTR(INVOICE_REFERENCE, 1, INSTR(INVOICE_REFERENCE, '-', 1, 1) - 1)
                ELSE
                    INVOICE_REFERENCE
            END
        ORDER BY INVOICE_REF_PREFIX;

    -- Variables to hold the necessary data
    v_invoice_ref_prefix VARCHAR2(50);
    v_oldest_date DATE;
    v_supplier_id VARCHAR2(10);
    v_order_id VARCHAR2(10);
    v_invoice_status VARCHAR2(50);
	v_total_amount   NUMBER(30, 2);
    ex_no_data_found EXCEPTION;

BEGIN
    -- Loop through each invoice reference prefix
    FOR invoice_rec IN invoice_cur LOOP
        v_invoice_ref_prefix := invoice_rec.invoice_ref_prefix;
        v_oldest_date := invoice_rec.oldest_date;

        BEGIN
            -- Get the supplier ID
            SELECT SUPPLIER_ID
            INTO v_supplier_id
            FROM XXBCM_SUPPLIER_NAME
            WHERE SUPPLIER_NAME = (
                SELECT SUPPLIER_NAME 
                FROM XXBCM_ORDER_MGT 
                WHERE INVOICE_REFERENCE LIKE v_invoice_ref_prefix || '%' 
                AND ROWNUM = 1
            );

            -- Get the correct order ID for the invoice reference
            SELECT ORDER_ID
            INTO v_order_id
            FROM XXBCM_ORDER_HEADER
            WHERE ORDER_REF = (SELECT SUBSTR(ORDER_REF , 1, INSTR(ORDER_REF , '-', 1, 1) - 1)
                FROM XXBCM_ORDER_MGT WHERE INVOICE_REFERENCE LIKE v_invoice_ref_prefix || '%' AND ROWNUM = 1);

            -- Determine the invoice status based on the conditions
            SELECT 
                CASE
                    WHEN COUNT(DISTINCT INVOICE_STATUS) = 1 AND MAX(INVOICE_STATUS) = 'Paid' THEN 'Paid'
                    WHEN COUNT(DISTINCT INVOICE_STATUS) = 1 AND MAX(INVOICE_STATUS) = 'Pending' THEN 'Pending'
                    WHEN COUNT(DISTINCT INVOICE_STATUS) > 1 THEN 'Partially Paid'
                END INTO v_invoice_status
            FROM 
                XXBCM_ORDER_MGT
            WHERE 
                INVOICE_REFERENCE LIKE v_invoice_ref_prefix || '%';
				
			-- Calculate the invoice amount i.e. sum of invoice line amount
			SELECT SUM(INVOICE_AMOUNT) AS total_amount
			into v_total_amount
			FROM XXBCM_ORDER_MGT
			where SUBSTR(INVOICE_REFERENCE, 1, INSTR(INVOICE_REFERENCE, '-', 1, 1) - 1) = v_invoice_ref_prefix
			GROUP BY SUBSTR(INVOICE_REFERENCE, 1, INSTR(INVOICE_REFERENCE, '-', 1, 1) - 1);

            -- Insert data into XXBCM_INVOICE_HEADER
            INSERT INTO XXBCM_INVOICE_HEADER (
                INVOICE_ID,
                INVOICE_REFERENCE,
                INVOICE_DATE,
                INVOICE_STATUS,
                SUPPLIER_ID,
                ORDER_ID,
				INVOICE_AMOUNT
            ) VALUES (
                'INV' || TO_CHAR(XXBCM_SEQ_INVOICE_ID.NEXTVAL, 'FM000000'),
                v_invoice_ref_prefix,
                v_oldest_date,
                v_invoice_status,
                v_supplier_id,
                v_order_id,
				v_total_amount
            );
           -- DBMS_OUTPUT.PUT_LINE(v_invoice_ref_prefix || '		' || v_invoice_status || '		' || v_supplier_id || '		' || v_order_id || '		' || v_total_amount);

        EXCEPTION
            -- Handle cases where no data is found in the lookup tables
            WHEN NO_DATA_FOUND THEN
                RAISE_APPLICATION_ERROR(-20001, 'Supplier ID or Order ID not found for invoice reference: ' || v_invoice_ref_prefix);
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20002, 'Error occurred during migration for invoice reference: ' || v_invoice_ref_prefix || ' - ' || SQLERRM);
        END;

    END LOOP;

    COMMIT;
	DBMS_OUTPUT.PUT_LINE('Invoice Header Data migrated successfully.');

EXCEPTION
    -- Handle the cursor when no data is found
    WHEN ex_no_data_found THEN
        RAISE_APPLICATION_ERROR(-20003, 'No data found for migration.');
   WHEN OTHERS THEN
    -- Handle any other exceptions that might occur
    DBMS_OUTPUT.PUT_LINE('Error inserting invoice header: ' || SQLERRM);
    ROLLBACK;
END MIGRATE_INVOICE_HEADER_DATA;
/


--------------------------------------------------------------------------------------------------------------------------------------------------------------
/*				PROCEDURE TO MIGRATE INVOICE LINE DATA		*/
--------------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE PROCEDURE MIGRATE_INVOICE_LINE_DATA AS
    -- Cursor to fetch distinct invoice lines
    CURSOR invoice_line_cur IS
        SELECT
            INVOICE_REFERENCE,
            TO_NUMBER(SUBSTR(INVOICE_REFERENCE, INSTR(INVOICE_REFERENCE, '-', -1) + 1)) AS invoice_line_number,
            INVOICE_DESCRIPTION,
            INVOICE_STATUS,
            TO_DATE(INVOICE_DATE, 'DD-MON-YY') AS invoice_line_date,
            INVOICE_AMOUNT
        FROM
            XXBCM_ORDER_MGT
        WHERE
            INVOICE_REFERENCE IS NOT NULL
        ORDER BY
            INVOICE_REFERENCE;

    -- Variables to hold the necessary data
    v_invoice_ref_prefix VARCHAR2(50);
    v_invoice_line_number INTEGER;
    v_invoice_description VARCHAR2(1000);
    v_invoice_line_status VARCHAR2(50);
    v_invoice_line_date DATE;
    v_invoice_amount NUMBER(14, 2);
    v_order_line_id VARCHAR2(10);
    v_invoice_id VARCHAR2(10);
    v_ORDER_line_number INTEGER;
    ex_no_data_found EXCEPTION;

BEGIN
    -- Loop through each invoice line
    FOR invoice_line_rec IN invoice_line_cur LOOP
        v_invoice_ref_prefix := SUBSTR(invoice_line_rec.INVOICE_REFERENCE, 1, INSTR(invoice_line_rec.INVOICE_REFERENCE, '-', 1, 1) - 1);
        v_invoice_line_number := invoice_line_rec.invoice_line_number;
        v_invoice_description := invoice_line_rec.INVOICE_DESCRIPTION;
        v_invoice_line_status := invoice_line_rec.INVOICE_STATUS;
        v_invoice_line_date := invoice_line_rec.invoice_line_date;
        v_invoice_amount := invoice_line_rec.INVOICE_AMOUNT;

        BEGIN
            -- Get the invoice ID from XXBCM_INVOICE_HEADER
            SELECT INVOICE_ID
            INTO v_invoice_id
            FROM XXBCM_INVOICE_HEADER
            WHERE INVOICE_REFERENCE = v_invoice_ref_prefix;

            -- Fetch the ORDER_LINE_ID based on the invoice's ORDER_ID from XXBCM_ORDER_HEADER
            -- Fetch ORDER_LINE_ID and ORDER_LINE_NUM for a given invoice reference
                SELECT ORDER_LINE_ID, ORDER_LINE_NUM
                INTO v_order_line_id, v_order_line_number
                FROM XXBCM_ORDER_LINE
                WHERE ORDER_ID = (
                    SELECT ORDER_ID
                    FROM XXBCM_INVOICE_HEADER
                    WHERE INVOICE_REFERENCE = v_invoice_ref_prefix
                )
                AND ORDER_LINE_STATUS <> 'Cancelled'
                AND ORDER_LINE_NUM = (
                    SELECT TO_NUMBER(SUBSTR(ORDER_REF, INSTR(ORDER_REF, '-') + 1), '99999999') AS LINE_NUM
                    FROM XXBCM_ORDER_MGT
                    WHERE INVOICE_REFERENCE = invoice_line_rec.INVOICE_REFERENCE
                )
                ORDER BY ORDER_ID,TO_NUMBER(ORDER_LINE_NUM,'99999999');
		

            -- Insert data into XXBCM_INVOICE_LINE
            INSERT INTO XXBCM_INVOICE_LINE (
                INVOICE_LINE_ID,
                INVOICE_ID,
                INVOICE_LINE_NUMBER,
                INVOICE_DESCRIPTION,
                INVOICE_LINE_STATUS,
                INVOICE_LINE_DATE,
                INVOICE_AMOUNT,
                ORDER_LINE_ID
            ) VALUES (
                'ILN' || TO_CHAR(XXBCM_SEQ_INVOICE_LINE_ID.NEXTVAL, 'FM000000'),
                v_invoice_id,
                v_invoice_line_number,
                v_invoice_description,
                v_invoice_line_status,
                v_invoice_line_date,
                v_invoice_amount,
                v_order_line_id
            ); 

            --DBMS_OUTPUT.PUT_LINE(v_invoice_id || '      ' || v_invoice_line_number || '      ' || v_order_line_id || '         ' || v_ORDER_line_number);

        EXCEPTION
            -- Handle cases where no data is found in the lookup tables
            WHEN NO_DATA_FOUND THEN
                RAISE_APPLICATION_ERROR(-20001, 'Invoice ID or Order Line ID not found for invoice reference: ' || v_invoice_ref_prefix);
            WHEN TOO_MANY_ROWS THEN
                RAISE_APPLICATION_ERROR(-20002, 'Multiple rows returned for invoice reference: ' || v_invoice_ref_prefix);
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20003, 'Error occurred during invoice line migration for reference: ' || invoice_line_rec.INVOICE_REFERENCE || ' - ' || SQLERRM);
        END;

    END LOOP;

    COMMIT;
DBMS_OUTPUT.PUT_LINE('Invoice Line Data migrated successfully.');


EXCEPTION
    -- Handle the cursor when no data is found
    WHEN ex_no_data_found THEN
        RAISE_APPLICATION_ERROR(-20004, 'No data found for invoice line migration.');
    WHEN OTHERS THEN
    -- Handle any other exceptions that might occur
    DBMS_OUTPUT.PUT_LINE('Error inserting invoice line: ' || SQLERRM);
    ROLLBACK;
END MIGRATE_INVOICE_LINE_DATA;
/


--------------------------------------------------------------------------------------------------------------------------------------------------------------
/*				PROCEDURE TO MIGRATE INVOICE LINE HOLD DATA		*/
--------------------------------------------------------------------------------------------------------------------------------------------------------------

create or replace PROCEDURE MIGRATE_INVOICE_LINE_HOLD_DATA AS
    -- Cursor to fetch invoice holds from the source table
    CURSOR invoice_line_hold_cur IS
        SELECT
            INVOICE_REFERENCE,
            INVOICE_HOLD_REASON
        FROM
            XXBCM_ORDER_MGT
        WHERE
            INVOICE_HOLD_REASON IS NOT NULL;

    -- Variables to hold the necessary data
    v_invoice_ref_prefix VARCHAR2(50);
    v_invoice_id VARCHAR2(10);
    v_invoice_line_id VARCHAR2(10);
    v_hold_reason VARCHAR2(1000);
    
BEGIN
    -- Loop through each invoice hold record
    FOR invoice_line_hold_rec IN invoice_line_hold_cur LOOP
        v_invoice_ref_prefix := SUBSTR(invoice_line_hold_rec.INVOICE_REFERENCE, 1, INSTR(invoice_line_hold_rec.INVOICE_REFERENCE, '-', 1, 1) - 1);
        v_hold_reason := invoice_line_hold_rec.INVOICE_HOLD_REASON;

        BEGIN
            -- Get the invoice ID from XXBCM_INVOICE_HEADER
            SELECT INVOICE_ID
            INTO v_invoice_id
            FROM XXBCM_INVOICE_HEADER
            WHERE INVOICE_REFERENCE = v_invoice_ref_prefix;

            -- Get the invoice line ID from XXBCM_INVOICE_LINE
            SELECT INVOICE_LINE_ID
            INTO v_invoice_line_id
            FROM XXBCM_INVOICE_LINE
            WHERE INVOICE_ID = v_invoice_id
              AND INVOICE_LINE_NUMBER = (
                SELECT TO_NUMBER(SUBSTR(INVOICE_REFERENCE, INSTR(INVOICE_REFERENCE, '-', -1) + 1))
                FROM XXBCM_ORDER_MGT
                WHERE INVOICE_REFERENCE = invoice_line_hold_rec.INVOICE_REFERENCE
              );

            -- Insert data into XXBCM_INVOICE_LINE_HOLD
            INSERT INTO XXBCM_INVOICE_LINE_HOLD (
                INVOICE_LINE_HOLD_ID,
                INVOICE_ID,
                INVOICE_LINE_ID,
                INVOICE_HOLD_REASON
            ) VALUES (
                'HLD' || TO_CHAR(XXBCM_SEQ_INVOICE_LINE_HOLD_ID.NEXTVAL, 'FM000000'),
                v_invoice_id,
                v_invoice_line_id,
                v_hold_reason
            ); 

            --DBMS_OUTPUT.PUT_LINE(v_invoice_id || ' ' || v_invoice_line_id || ' ' || v_hold_reason);

        EXCEPTION
            -- Handle cases where no data is found in the lookup tables
            WHEN NO_DATA_FOUND THEN
                RAISE_APPLICATION_ERROR(-20001, 'Invoice ID or Invoice Line ID not found for invoice reference: ' || v_invoice_ref_prefix);
            WHEN TOO_MANY_ROWS THEN
                RAISE_APPLICATION_ERROR(-20002, 'Multiple rows returned for invoice reference: ' || v_invoice_ref_prefix);
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20003, 'Error occurred during invoice line hold migration for reference: ' || invoice_line_hold_rec.INVOICE_REFERENCE || ' - ' || SQLERRM);
        END;

    END LOOP;

    COMMIT;
	DBMS_OUTPUT.PUT_LINE('Invoice Line Hold Data migrated successfully.');


EXCEPTION
   WHEN OTHERS THEN
    -- Handle any other exceptions that might occur
    DBMS_OUTPUT.PUT_LINE('Error inserting invoice line hold: ' || SQLERRM);
    ROLLBACK;
END MIGRATE_INVOICE_LINE_HOLD_DATA;
/