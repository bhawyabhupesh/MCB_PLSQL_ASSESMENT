--------------------------------------------------------------------------------------------------------------------------------------------------------------
/*				PACKAGE HEADER TO CREATE MIGRATION_PKG		*/
--------------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE PACKAGE MIGRATION_PKG AS
    PROCEDURE EXECUTE_PROCEDURES;
END MIGRATION_PKG;
/

--------------------------------------------------------------------------------------------------------------------------------------------------------------
/*				MIGRATION_PKG PACKAGE BODY		*/
--------------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE PACKAGE BODY MIGRATION_PKG AS

    PROCEDURE EXECUTE_PROCEDURES IS
    BEGIN
        BEGIN
            CLEANSE_ORDER_DATA;
			
            CLEANSE_INVOICE_REFS;

            MIGRATE_SUPPLIER_DATA;

            MIGRATE_SUPPLIER_CONTACT_DATA;

            MIGRATE_SUPPLIER_ADDRESS_DATA;

            MIGRATE_ORDER_HEADER;

            MIGRATE_ORDER_LINES;

            MIGRATE_INVOICE_HEADER_DATA;

            MIGRATE_INVOICE_LINE_DATA;

            MIGRATE_INVOICE_LINE_HOLD_DATA;

        EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20002, 'Error occurred during execution: ' || SQLERRM);
        END;
    END EXECUTE_PROCEDURES;

END MIGRATION_PKG;

