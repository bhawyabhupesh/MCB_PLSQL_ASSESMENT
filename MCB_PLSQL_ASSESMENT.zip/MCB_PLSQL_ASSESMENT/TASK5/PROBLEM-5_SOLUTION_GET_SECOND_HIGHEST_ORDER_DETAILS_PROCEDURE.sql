create or replace PROCEDURE get_second_highest_order_details IS
    v_order_ref           VARCHAR2(50);
    v_order_date          VARCHAR2(50);
    v_supplier_name       VARCHAR2(100);
    v_order_total_amount  VARCHAR2(20);
    v_order_status        VARCHAR2(50);
    v_invoice_references  VARCHAR2(4000);

BEGIN
    -- Select the details for the second-highest order total amount

	SELECT ORDER_REF, ORDER_DATE, SUPPLIER_NAME, ORDER_TOTAL_AMOUNT, ORDER_STATUS, INVOICE_REFERENCES
INTO v_order_ref, v_order_date, v_supplier_name, v_order_total_amount, v_order_status, v_invoice_references
FROM (
    SELECT 
        oh.ORDER_REF, 
        oh.ORDER_DATE, 
        sn.SUPPLIER_NAME, 
        oh.ORDER_TOTAL_AMOUNT, 
        oh.ORDER_STATUS, 
        LISTAGG(DISTINCT ih.INVOICE_REFERENCE || '-' || il.INVOICE_LINE_NUMBER, ' | ') 
            WITHIN GROUP (ORDER BY ih.INVOICE_REFERENCE) AS INVOICE_REFERENCES,
        RANK() OVER (ORDER BY oh.ORDER_TOTAL_AMOUNT DESC) AS rnk
    FROM 
        XXBCM_ORDER_HEADER oh
    JOIN 
        XXBCM_SUPPLIER_NAME sn ON oh.SUPPLIER_ID = sn.SUPPLIER_ID
    JOIN 
        XXBCM_ORDER_LINE ol ON oh.ORDER_ID = ol.ORDER_ID
    LEFT JOIN 
        XXBCM_INVOICE_HEADER ih ON oh.ORDER_ID = ih.ORDER_ID
    LEFT JOIN 
        XXBCM_INVOICE_LINE il ON ih.invoice_id = il.invoice_id
    GROUP BY 
        oh.ORDER_REF, oh.ORDER_DATE, sn.SUPPLIER_NAME, oh.ORDER_TOTAL_AMOUNT, oh.ORDER_STATUS
    ) 
WHERE rnk = 2;

	DBMS_OUTPUT.PUT_LINE('Below output shows 2nd highest order details-');
	DBMS_OUTPUT.PUT_LINE('');
	DBMS_OUTPUT.PUT_LINE('');

    DBMS_OUTPUT.PUT_LINE('Order Reference: ' || v_order_ref);
    DBMS_OUTPUT.PUT_LINE('Order Date: ' || v_order_date);
    DBMS_OUTPUT.PUT_LINE('Supplier Name: ' || v_supplier_name);
    DBMS_OUTPUT.PUT_LINE('Order Total Amount: ' || v_order_total_amount);
    DBMS_OUTPUT.PUT_LINE('Order Status: ' || v_order_status);
    DBMS_OUTPUT.PUT_LINE('Invoice References: ' || v_invoice_references);
	
	DBMS_OUTPUT.PUT_LINE('');
	DBMS_OUTPUT.PUT_LINE('');
	DBMS_OUTPUT.PUT_LINE('2nd highest order details fetched successfully.');
	DBMS_OUTPUT.PUT_LINE('');
	DBMS_OUTPUT.PUT_LINE('------------------------------------------------------------------------------------------');
	DBMS_OUTPUT.PUT_LINE('------------------------------------------------------------------------------------------');
	DBMS_OUTPUT.PUT_LINE('');
	DBMS_OUTPUT.PUT_LINE('');

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('No record found.');
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20001, 'Error occurred while fetching the second highest order details: ' || SQLERRM);
END get_second_highest_order_details;
