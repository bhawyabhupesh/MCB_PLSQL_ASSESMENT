CREATE OR REPLACE PROCEDURE GET_SUPPLIER_ORDER_SUMMARY(
    p_start_date IN DATE,
    p_end_date IN DATE
) 
IS
    -- Cursor to hold the supplier data
    CURSOR c_supplier_orders IS
        SELECT
            s.supplier_name AS supplier_name,
            c.SUPP_CONTACT_NAME AS SUPP_CONTACT_NAME,
            -- Formatting the first contact number from the contact table
            CASE 
                WHEN LENGTH(c.SUPP_CONTACT_NUMBER1) = 7 THEN SUBSTR(c.SUPP_CONTACT_NUMBER1, 1, 3) || '-' || SUBSTR(c.SUPP_CONTACT_NUMBER1, 4, 4)
                WHEN LENGTH(c.SUPP_CONTACT_NUMBER1) = 8 THEN SUBSTR(c.SUPP_CONTACT_NUMBER1, 1, 4) || '-' || SUBSTR(c.SUPP_CONTACT_NUMBER1, 5, 4)
            END AS SUPP_CONTACT_NUMBER1,
            -- Formatting the second contact number from the contact table
            CASE 
                WHEN LENGTH(c.SUPP_CONTACT_NUMBER2) = 7 THEN SUBSTR(c.SUPP_CONTACT_NUMBER2, 1, 3) || '-' || SUBSTR(c.SUPP_CONTACT_NUMBER2, 4, 4)
                WHEN LENGTH(c.SUPP_CONTACT_NUMBER2) = 8 THEN SUBSTR(c.SUPP_CONTACT_NUMBER2, 1, 4) || '-' || SUBSTR(c.SUPP_CONTACT_NUMBER2, 5, 4)
            END AS SUPP_CONTACT_NUMBER2,
            COUNT(o.order_id) AS total_orders,
            TO_CHAR(SUM(l.ORDER_LINE_AMOUNT), 'FM99,999,990.00') AS order_total_amount
        FROM
            XXBCM_SUPPLIER_NAME s
            JOIN XXBCM_SUPPLIER_CONTACT c ON s.supplier_id = c.supplier_id
            JOIN XXBCM_ORDER_HEADER o ON s.supplier_id = o.supplier_id
			JOIN XXBCM_ORDER_LINE l ON o.order_id = l.order_id
        WHERE
            o.order_date BETWEEN p_start_date AND p_end_date
			and l.ORDER_LINE_STATUS <> 'Cancelled'
        GROUP BY
            s.supplier_name, c.SUPP_CONTACT_NAME, c.SUPP_CONTACT_NUMBER1, c.SUPP_CONTACT_NUMBER2
        ORDER BY
            s.supplier_name;
        
    -- Variable to store supplier record
    rec_supplier c_supplier_orders%ROWTYPE;
    
BEGIN
    -- Open the cursor
    OPEN c_supplier_orders;
    
    -- Print the header row
	DBMS_OUTPUT.PUT_LINE('Below output shows supplier, supplier contact, number of orders and total ordered amount-');
	DBMS_OUTPUT.PUT_LINE('');
	DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('Supplier Name | Contact Name | Contact No. 1 | Contact No. 2 | Total Orders | Order Total Amount');
    DBMS_OUTPUT.PUT_LINE('------------------------------------------------------------------------------------------');
    
    -- Fetch each record and display
    LOOP
        FETCH c_supplier_orders INTO rec_supplier;
        EXIT WHEN c_supplier_orders%NOTFOUND;
        
        -- Print each row with columns separated by |
        DBMS_OUTPUT.PUT_LINE(
            rec_supplier.supplier_name || ' | ' ||
            rec_supplier.SUPP_CONTACT_NAME || ' | ' ||
            rec_supplier.SUPP_CONTACT_NUMBER1 || ' | ' ||
            rec_supplier.SUPP_CONTACT_NUMBER2 || ' | ' ||
            rec_supplier.total_orders || ' | ' ||
            rec_supplier.order_total_amount
        );
    END LOOP;
    
    -- Close the cursor
    CLOSE c_supplier_orders;
	DBMS_OUTPUT.PUT_LINE('');
	DBMS_OUTPUT.PUT_LINE('');
	DBMS_OUTPUT.PUT_LINE('Supplier order summary fetched successfully.');
	DBMS_OUTPUT.PUT_LINE('');
	DBMS_OUTPUT.PUT_LINE('------------------------------------------------------------------------------------------');
	DBMS_OUTPUT.PUT_LINE('------------------------------------------------------------------------------------------');
	DBMS_OUTPUT.PUT_LINE('');
	DBMS_OUTPUT.PUT_LINE('');
   
EXCEPTION
    WHEN OTHERS THEN
        -- Handle any other exceptions
        DBMS_OUTPUT.PUT_LINE('An error occurred: ' || SQLERRM);
END GET_SUPPLIER_ORDER_SUMMARY;