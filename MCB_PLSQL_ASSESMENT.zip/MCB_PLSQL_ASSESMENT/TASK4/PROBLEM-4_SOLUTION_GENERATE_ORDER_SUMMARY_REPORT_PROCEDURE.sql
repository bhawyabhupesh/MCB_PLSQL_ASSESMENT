CREATE OR REPLACE PROCEDURE GENERATE_ORDER_SUMMARY_REPORT AS
    -- Cursor to fetch order and invoice data
    CURSOR order_summary_cur IS
        SELECT
            TO_NUMBER(TRIM(REPLACE(o.ORDER_REF, 'PO', '')),'9999') AS ORDER_REFERENCE,
            TO_CHAR(o.ORDER_DATE, 'MON-YYYY') AS ORDER_PERIOD,
            INITCAP(s.SUPPLIER_NAME) AS SUPPLIER_NAME,
            TO_CHAR(SUM(i.INVOICE_AMOUNT), 'FM999,999,990.00') AS ORDER_TOTAL_AMOUNT,
            o.ORDER_STATUS AS ORDER_STATUS,
            i.INVOICE_REFERENCE AS INVOICE_REFERENCE,
            TO_CHAR(SUM(i.INVOICE_AMOUNT), 'FM999,999,990.00') AS INVOICE_TOTAL_AMOUNT,
            CASE
                WHEN MIN(i.INVOICE_STATUS) IS NULL THEN 'To verify'
                WHEN COUNT(DISTINCT i.INVOICE_STATUS) = 1 AND MIN(i.INVOICE_STATUS) = 'Paid' THEN 'OK'
                WHEN COUNT(DISTINCT i.INVOICE_STATUS) = 1 AND MIN(i.INVOICE_STATUS) = 'Pending' THEN 'To follow up'
                ELSE 'To follow up'
            END AS ACTION
        FROM
            XXBCM_ORDER_HEADER o
            JOIN XXBCM_INVOICE_HEADER i ON o.ORDER_ID = i.ORDER_ID
            JOIN XXBCM_SUPPLIER_NAME s ON o.SUPPLIER_ID = s.SUPPLIER_ID
        GROUP BY
            o.ORDER_REF,
            o.ORDER_DATE,
            s.SUPPLIER_NAME,
            o.ORDER_STATUS,
            i.INVOICE_REFERENCE
        ORDER BY
            o.ORDER_DATE DESC;

    -- Variable to hold the data
    v_order_reference VARCHAR2(50);
    v_order_period VARCHAR2(20);
    v_supplier_name VARCHAR2(100);
    v_order_total_amount VARCHAR2(50);
    v_order_status VARCHAR2(50);
    v_invoice_reference VARCHAR2(50);
    v_invoice_total_amount VARCHAR2(50);
    v_action VARCHAR2(50);

BEGIN
    -- Output headers for report
	DBMS_OUTPUT.PUT_LINE('Below output shows order summary details-');
	DBMS_OUTPUT.PUT_LINE('');
	DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('Order Reference | Order Period | Supplier Name | Order Total Amount | Order Status | Invoice Reference | Invoice Total Amount | Action');

    -- Loop through each record in the cursor
    FOR rec IN order_summary_cur LOOP
        -- Assign values to variables
        v_order_reference := rec.ORDER_REFERENCE;
        v_order_period := rec.ORDER_PERIOD;
        v_supplier_name := rec.SUPPLIER_NAME;
        v_order_total_amount := rec.ORDER_TOTAL_AMOUNT;
        v_order_status := rec.ORDER_STATUS;
        v_invoice_reference := rec.INVOICE_REFERENCE;
        v_invoice_total_amount := rec.INVOICE_TOTAL_AMOUNT;
        v_action := rec.ACTION;

        -- Output the data
        DBMS_OUTPUT.PUT_LINE(v_order_reference || ' | ' ||
                             v_order_period || ' | ' ||
                             v_supplier_name || ' | ' ||
                             v_order_total_amount || ' | ' ||
                             v_order_status || ' | ' ||
                             v_invoice_reference || ' | ' ||
                             v_invoice_total_amount || ' | ' ||
                             v_action);
    END LOOP;
	DBMS_OUTPUT.PUT_LINE('');
	DBMS_OUTPUT.PUT_LINE('');
	DBMS_OUTPUT.PUT_LINE('Order summary fetched successfully.');
	DBMS_OUTPUT.PUT_LINE('');
	DBMS_OUTPUT.PUT_LINE('------------------------------------------------------------------------------------------');
	DBMS_OUTPUT.PUT_LINE('------------------------------------------------------------------------------------------');
	DBMS_OUTPUT.PUT_LINE('');
	DBMS_OUTPUT.PUT_LINE('');
	
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error occurred: ' || SQLERRM);
		
END GENERATE_ORDER_SUMMARY_REPORT;

